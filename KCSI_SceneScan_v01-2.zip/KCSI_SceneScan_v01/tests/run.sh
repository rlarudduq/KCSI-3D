#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
javac -d "$tmp" app/src/main/java/kr/kcsi/scenescan/Geometry.java tests/GeometryTest.java
java -cp "$tmp" kr.kcsi.scenescan.GeometryTest "$@"
