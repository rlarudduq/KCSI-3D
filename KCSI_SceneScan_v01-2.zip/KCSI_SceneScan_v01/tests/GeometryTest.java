package kr.kcsi.scenescan;
import java.io.*;
import java.nio.*;
import java.util.*;
public final class GeometryTest {
    static void ok(boolean cond,String reason){if(!cond)throw new AssertionError(reason);}
    public static void main(String[] args)throws Exception{
        float[] p=Geometry.unproject(160,120,2,100,100,160,120);ok(Arrays.equals(p,new float[]{0,-0f,-2}),"optical axis");
        float[] q=Geometry.unproject(210,145,2,100,100,160,120);ok(Math.abs(q[0]-1)<1e-6&&Math.abs(q[1]+.5f)<1e-6,"projection axes");
        Geometry.Store s=new Geometry.Store();s.point(new float[]{.001f,0,0},0xff0000);s.point(new float[]{.002f,0,0},0x0000ff);ok(s.count()==1,"voxel merge");s.point(new float[]{Float.NaN,0,0},0);ok(s.count()==1,"reject nan");
        s.triangle(new float[]{0,0,0},new float[]{.04f,0,0},new float[]{0,.05f,0},0xff0000,0xffffff,0);s.triangle(new float[]{0,0,0},new float[]{1,0,0},new float[]{0,1,0},0,0,0);ok(s.triCount()==1,"reject long edges");
        ByteArrayOutputStream out=new ByteArrayOutputStream();Geometry.ply(s.snapshot(false),out);byte[] ply=out.toByteArray();String txt=new String(ply,java.nio.charset.StandardCharsets.ISO_8859_1);ok(txt.contains("element vertex 1"),"PLY count");ok(ply.length-txt.indexOf("end_header\n")-11==15,"PLY vertex bytes");
        out.reset();Geometry.glb(s.snapshot(true),true,out);byte[] glb=out.toByteArray();ByteBuffer b=ByteBuffer.wrap(glb).order(ByteOrder.LITTLE_ENDIAN);ok(b.getInt()==0x46546c67&&b.getInt()==2&&b.getInt()==glb.length,"GLB header");int j=b.getInt();ok(j%4==0&&b.getInt()==0x4e4f534a,"JSON header");byte[] js=new byte[j];b.get(js);ok(new String(js).contains("\"mode\":4"),"triangle mode");ok(b.getInt()==48&&b.getInt()==0x004e4942&&b.remaining()==48,"BIN length");if(args.length>0){try(FileOutputStream f=new FileOutputStream(args[0])){f.write(glb);}}System.out.println("PASS: unprojection, voxel merge, depth discontinuity, PLY and GLB structure");
    }
}
