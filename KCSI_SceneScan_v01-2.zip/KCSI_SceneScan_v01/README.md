# KCSI Scene Scan v0.4 — Android 실험 프로젝트

**상태: 소스코드와 GitHub Actions 빌드 설정. APK 미생성 / Android 실제 컴파일 및 실기기 시험 미수행.**

## 무엇을 하나요?
- ARCore 카메라 자세 추적 및 Raw Depth/신뢰도 수집. 원시 깊이 및 필요시 일반 Depth 보완값으로부터 카메라 좌표를 ARCore 월드 좌표로 변환하고 약 3.5cm 복셀로 누적합니다.
- RGB 카메라 YUV 이미지에서 각 깊이 샘플의 색상을 추출합니다. RGB를 취득하지 못한 경우 회색으로 표시하고 진단에 상태를 남깁니다. 그림을 붙인 가상의 방이나 가구는 생성하지 않습니다.
- 촬영 중 컬러 점군 오버레이, 종료 후 터치 회전/핀치 확대, 점군/실험 표면 전환.
- 실험 표면: ARCore의 일반 Depth 이미지(보간된 추정 깊이 포함)에서 인접 깊이 샘플만 연결합니다. 약 13cm 이상의 긴 모서리를 제거하고, 관측되지 않은 면을 메우지 않습니다. 프레임별 패치이므로 겹침, 구멍, 드리프트가 존재할 수 있습니다. 정합된 밀집 메시/UV 텍스처가 아닙니다. 색상은 정점 색상입니다.
- 점군 PLY 및 실험 표면 GLB 로컬 저장. 원본 사진/AR 세션 전체 기록 보존과 오프라인 HTML 내보내기는 아직 미구현입니다.
- SfM 재정합/Bundle Adjustment/MVS는 별개이며 이번 버전에는 구현하지 않았습니다. 이번 버전은 ARCore 깊이 시험입니다.

## Android Studio 없이 APK 빌드 (방법 A: GitHub 웹)
1. GitHub에서 새 **Private** 저장소를 만들고 README 초기화를 선택합니다.
2. 배포받은 `KCSI_SceneScan_v01.zip` 파일을 압축 해제하지 않고 리포지터리 루트에 업로드합니다 (Add file > Upload files).
3. Add file > Create new file을 누르고 파일 이름을 `.github/workflows/build.yml`로 입력합니다.
4. 함께 제공된 `KCSI_build_from_zip.yml`의 전체 텍스트를 붙여넣고 Commit changes 합니다. 필요하면 Actions 탭에서 워크플로 허용 설정을 합니다.
5. Actions > Build KCSI Scene Scan from ZIP > Run workflow (main) 실행. 커밋으로 자동 시작될 수도 있습니다.
6. 성공한 실행 하단 Artifacts에서 `KCSI-SceneScan-v0.1-debug` ZIP을 내려받아 압축을 풀면 `app-debug.apk`가 나옵니다.
7. 개인 테스트용 S26+에 APK를 설치합니다. 업무용 기기는 소속기관 보안 승인 없이 설치하지 않습니다. 디버그 서명은 테스트용이며 공개 배포에는 별도 서명이 필요합니다.

## 방법 B: 일반 Git 프로젝트
압축을 풀어 내용 전체(숨김 `.github` 포함)를 Git 리포지터리에 커밋하고 푸시하면 내장된 `.github/workflows/build.yml`로 자동 빌드됩니다. 프로젝트는 AGP 8.7.3/Gradle 8.9/JDK 17/compileSdk 35/ARCore 1.48.0을 사용합니다. SDK가 갖춰진 컴퓨터에서 `gradle :app:assembleDebug`로도 빌드할 수 있습니다. Gradle wrapper는 포함되지 않았습니다.

## 스마트폰 시험
- 최초 1회 Google Play Services for AR 설치/업데이트 및 기기 지원 확인에 인터넷과 Google Play가 필요할 수 있습니다. 준비가 된 이후 비행기 모드/오프라인 동작을 시험하세요. 앱 자체에는 INTERNET 권한을 명시하지 않았으나 최종 병합 manifest 및 기기 통신 여부는 빌드 후 검사해야 합니다. 사건자료 대신 테스트 장면만 사용하세요.
- 카메라 허용, 가로 화면에서 촬영 시작. 작은 방에서 천천히 30~60초 이동하며 벽과 물체를 다양한 각도로 관찰하세요. 한 자리 회전만 피합니다. 깊이 유효 거리 0.35~5m 및 원시 신뢰도 110/255 이상만 사용합니다. 반사/단색/투명 재질은 누락될 수 있습니다.
- 촬영 종료 / 3D 버튼. 점군과 표면(실험) 전환. 저장은 로컬 기기 폴더 선택 (클라우드 드라이브 선택하지 마세요).
- 앱 종료 시 세션은 메모리에서 사라지므로 결과물을 먼저 저장합니다. 시험용 데이터 상한은 16만 복셀 및 10만 삼각형입니다. 상한에 도달하면 뒤쪽 영역이 추가되지 않을 수 있습니다. 촬영 중 앱 전환은 피하고 추적이 유실되면 원래 관측 영역에서 천천히 재개하세요.
- 3D 모델과 원본 사진의 재현 정도, 누락 면, 실제 촬영/생성 시간, 온도와 메모리, 재촬영 간 차이를 기록하세요. 계측 정확도 및 법과학 검증은 수행되지 않았습니다.

## 테스트 내역
`bash tests/run.sh` : 일반 JDK에서 unproject, 복셀 평균/이상치, 긴 모서리 필터, PLY 및 GLB 구조의 독립 테스트 통과. 샘플 GLB는 trimesh로 삼각형 1개 정상 로드 확인. 이 테스트는 합성 수치를 사용하며 현장 복원 테스트는 아님. Android SDK 및 외부 다운로드 제한으로 Android 앱은 빌드/실행하지 못했습니다. 첫 GitHub 빌드에서 컴파일 오류가 있다면 로그가 필요합니다.

## 기술 참고
- https://developers.google.com/ar/develop/java/depth/raw-depth
- https://codelabs.developers.google.com/codelabs/arcore-rawdepthapi
- https://developers.google.com/ar/develop/java/depth/developer-guide
- https://developers.google.com/ar/reference/java/com/google/ar/core/Frame


## v0.2 진단 수정
- 촬영 시작 확인 표시, 촬영 종료 버튼 고정, 추적 실패 사유와 깊이/RGB 대기 상태 표시.
- Raw Depth의 이전 타임스탬프와 비교해 새 추정값의 수집 여부를 판단.
- 데이터가 비어 있으면 종료하지 않도록 안내하며 Raw Depth가 없어도 표면만 있으면 표시.
- 실제 S26+ 동작은 미검증. 기존 workflow 호환을 위해 ZIP과 내부 폴더 이름은 v01로 유지.

## v0.3 (이번 수정)
- 가로 전체 화면의 카메라/3D 위에 작은 상태 패널과 촬영/종료 버튼만 표시. 점군·표면·PLY·GLB·다시 촬영은 종료 후 표시.
- 우측 ⋯ > 촬영 진단에서 카메라 업데이트, 추적 실패 사유, AR 특징점(진단 용도), Raw/일반 Depth 요청·취득·채택, RGB 상태, 최근 예외를 확인하고 복사 가능.
- RGB 요청 실패와 두 깊이 경로를 분리. Raw 포인트가 아직 없으면 일반 Depth(보간된 추정값)의 유효 픽셀에서 점과 국소 표면을 생성. PLY에 혼합 출처 가능성과 비계측 주의 명기.
- 상단 깊이 수는 원시 점 채택 프레임과 일반 깊이 채택 프레임의 합(동일 카메라 프레임이 양쪽에 포함될 수 있음). 전체 카메라 프레임 수는 진단에서 확인.
- 앱 버전 0.3.0 / versionCode 3. 기존 ZIP명 및 내부 폴더 유지. GitHub workflow 수정 없이 ZIP 덮어쓰기.
- 독립 자바 기하/저장 테스트 통과. 실제 Android 빌드와 S26+ 동작은 미검증. 실패 시 10~20초 이동 후 진단 화면/복사 내용 전달. 실제 사건자료 대신 시험 장면만 촬영.

## v0.4
- 오른쪽 중앙 세로 버튼: 시작 / 일시중지 / 재개 (86×60dp), 종료 / 3D (76×44dp). 일시중지는 기존 모델 및 카운터를 유지하며 재개 시 이어서 촬영합니다.
- 종료 버튼은 촬영 개시 이후 활성화되고 3D 보기에서는 숨겨집니다. 기존 저장 및 진단 기능 유지.
- 버전 0.4.0 / versionCode 4. ZIP과 내부 폴더명 기존과 동일. Android 실기기 검증은 별도 필요.
