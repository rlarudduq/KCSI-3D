package kr.kcsi.scenescan;
import java.io.*;
import java.nio.*;
import java.util.*;
public final class GeometryTest {
    static void ok(boolean cond,String reason){if(!cond)throw new AssertionError(reason);}
    public static void main(String[] args)throws Exception{
        float[] p=Geometry.unproject(160,120,2,100,100,160,120);ok(Arrays.equals(p,new float[]{0,-0f,-2}),"optical axis");
        float[] q=Geometry.unproject(210,145,2,100,100,160,120);ok(Math.abs(q[0]-1)<1e-6&&Math.abs(q[1]+.5f)<1e-6,"projection axes");
        // Little-endian depth decoding with a non-zero buffer start and padded rows.
        ByteBuffer dep=ByteBuffer.allocate(22).order(ByteOrder.BIG_ENDIAN);dep.position(2);
        int[] vals={0,750,200,9000,1500,65535};for(int i=0;i<6;i++){int offset=2+(i/3)*10+(i%3)*2;dep.put(offset,(byte)vals[i]);dep.put(offset+1,(byte)(vals[i]>>8));}
        ByteBuffer conf=ByteBuffer.allocate(10);conf.position(1);conf.put(2,(byte)255);conf.put(6,(byte)20);
        ok(Geometry.readU16(dep,4)==750,"unsigned little endian depth");ok(Geometry.readU16(dep,16)==65535,"unsigned max depth");
        String stats=Geometry.depthStats(dep,3,2,10,2,conf,4,1);
        ok(stats.contains("0값 1")&&stats.contains("비0 5")&&stats.contains("200~65535 mm")&&stats.contains("거리탈락 3")&&stats.contains("신뢰도탈락 1")&&stats.contains("유효 1"),"depth diagnostics "+stats);
        String allZero=Geometry.depthStats(ByteBuffer.allocate(8),2,2,4,2,null,0,0);ok(allZero.contains("0값 4")&&allZero.contains("비0 0")&&allZero.contains("유효 0"),"zero depth detection");
        ByteBuffer far=ByteBuffer.allocate(160*90*2).order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<160*90;i++)far.putShort(i*2,(short)18000);
        Geometry.Quality fq=Geometry.quality(far,160,90,320,2,null,0,0);ok(!fq.acceptable(true)&&fq.median==18000&&fq.good==0,"reject implausible entire depth frame");
        ByteBuffer normal=ByteBuffer.allocate(160*90*2).order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<160*90;i++)normal.putShort(i*2,(short)1500);
        Geometry.Quality nq=Geometry.quality(normal,160,90,320,2,null,0,0);ok(nq.acceptable(true)&&nq.centerMedian==1500,"accept normal depth frame");
        ok(!Geometry.reasonableTravel(new float[]{65,0,0})&&Geometry.reasonableTravel(new float[]{2,0,0}),"room movement gate");
        Geometry.Store s=new Geometry.Store();s.point(new float[]{.001f,0,0},0xff0000);s.point(new float[]{.002f,0,0},0x0000ff);ok(s.count()==1,"voxel merge");s.point(new float[]{Float.NaN,0,0},0);ok(s.count()==1,"reject nan");
        s.triangle(new float[]{0,0,0},new float[]{.04f,0,0},new float[]{0,.05f,0},0xff0000,0xffffff,0);s.triangle(new float[]{0,0,0},new float[]{1,0,0},new float[]{0,1,0},0,0,0);ok(s.triCount()==1,"reject long edges");
        ByteArrayOutputStream out=new ByteArrayOutputStream();Geometry.ply(s.snapshot(false),out);byte[] ply=out.toByteArray();String txt=new String(ply,java.nio.charset.StandardCharsets.ISO_8859_1);ok(txt.contains("element vertex 1"),"PLY count");ok(ply.length-txt.indexOf("end_header\n")-11==15,"PLY vertex bytes");
        out.reset();Geometry.glb(s.snapshot(true),true,out);byte[] glb=out.toByteArray();ByteBuffer b=ByteBuffer.wrap(glb).order(ByteOrder.LITTLE_ENDIAN);ok(b.getInt()==0x46546c67&&b.getInt()==2&&b.getInt()==glb.length,"GLB header");int j=b.getInt();ok(j%4==0&&b.getInt()==0x4e4f534a,"JSON header");byte[] js=new byte[j];b.get(js);ok(new String(js).contains("\"mode\":4"),"triangle mode");ok(b.getInt()==48&&b.getInt()==0x004e4942&&b.remaining()==48,"BIN length");if(args.length>0){try(FileOutputStream f=new FileOutputStream(args[0])){f.write(glb);}}System.out.println("PASS: depth decoding and diagnostics, unprojection, voxel merge, depth discontinuity, PLY and GLB structure");
    }
}
