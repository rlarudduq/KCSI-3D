package kr.kcsi.scenescan;

import java.util.*;
import java.io.*;
import java.nio.*;

/** Android-independent geometry and file output. All coordinates are in ARCore metres. */
final class Geometry {
    static final int POINT_LIMIT=160000, TRI_LIMIT=100000;
    static final float VOXEL=.035f;
    // Experimental acceptance range. Zero depth is always invalid.
    static final int MIN_DEPTH_MM=250,MAX_DEPTH_MM=8000,MIN_CONFIDENCE=64;
    static int readU16(ByteBuffer b,int i){return (b.get(i)&255)|((b.get(i+1)&255)<<8);}
    static String depthStats(ByteBuffer b,int w,int h,int row,int pixel,ByteBuffer conf,int cr,int cp){
        int zero=0,nonzero=0,out=0,low=0,accepted=0,missing=0,min=65536,max=0,confMax=0;
        for(int y=0;y<h;y++)for(int x=0;x<w;x++){
            int i=b.position()+y*row+x*pixel;if(i<0||i+1>=b.limit()){missing++;continue;}
            int d=readU16(b,i);if(d==0){zero++;continue;}nonzero++;min=Math.min(min,d);max=Math.max(max,d);
            if(d<MIN_DEPTH_MM||d>MAX_DEPTH_MM){out++;continue;}
            if(conf!=null){int ci=conf.position()+y*cr+x*cp;int c=ci>=0&&ci<conf.limit()?conf.get(ci)&255:0;confMax=Math.max(confMax,c);if(c<MIN_CONFIDENCE){low++;continue;}}
            accepted++;
        }
        return "전체 "+(w*h)+" / 0값 "+zero+" / 비0 "+nonzero+" / 깊이 "+(nonzero==0?"없음":min+"~"+max+" mm")+" / 거리탈락 "+out+" / 신뢰도탈락 "+low+" / 유효 "+accepted+" / 읽기불가 "+missing+(conf!=null?" / 신뢰도최대 "+confMax:"")+" / stride "+row+","+pixel;
    }
    // Reject isolated depth speckles and frames dominated by out-of-room estimates.
    // Counts refer to raw pixels; no synthetic depths or rescaling are introduced.
    static final class Quality {
        int total,nonzero,near,good,median,centerMedian;
        boolean acceptable(boolean surface){return surface ? good>=Math.max(40,total/10) && median>=MIN_DEPTH_MM && median<=MAX_DEPTH_MM : good>=Math.max(20,total/500);}
        public String toString(){return "중앙 영역 중앙값 "+centerMedian+" mm / 전체 중앙값 "+median+" mm / 범위 내 "+near+" / 채택 가능 "+good+" / 전체 "+total;}
    }
    static Quality quality(ByteBuffer b,int w,int h,int row,int pixel,ByteBuffer conf,int cr,int cp){
        Quality q=new Quality();q.total=w*h;int[] all=new int[q.total],center=new int[q.total];int cn=0;
        for(int y=0;y<h;y++)for(int x=0;x<w;x++){
            int i=b.position()+y*row+x*pixel;if(i<0||i+1>=b.limit())continue;int d=readU16(b,i);if(d==0)continue;
            all[q.nonzero++]=d;if(x>=w/4&&x<3*w/4&&y>=h/4&&y<3*h/4)center[cn++]=d;
            if(d<MIN_DEPTH_MM||d>MAX_DEPTH_MM)continue;q.near++;
            if(conf!=null){int k=conf.position()+y*cr+x*cp;if(k<0||k>=conf.limit()||(conf.get(k)&255)<MIN_CONFIDENCE)continue;}q.good++;
        }
        if(q.nonzero>0){Arrays.sort(all,0,q.nonzero);q.median=all[q.nonzero/2];}if(cn>0){Arrays.sort(center,0,cn);q.centerMedian=center[cn/2];}return q;
    }
    static boolean reasonableTravel(float[] p){return valid(p)&&dist2(p,new float[]{0,0,0})<=100f;}
    static final class Model {
        final float[] xyz; final byte[] rgba; final int[] indices;
        Model(float[] xyz,byte[] rgba,int[] indices){this.xyz=xyz;this.rgba=rgba;this.indices=indices;}
        int size(){return xyz.length/3;}
    }
    static final class Voxel {
        float x,y,z,r,g,b; int n;
        Voxel(float[] p,int color){x=p[0];y=p[1];z=p[2];r=(color>>16)&255;g=(color>>8)&255;b=color&255;n=1;}
        void add(float[] p,int color){if(n>=24)return;float a=1f/(++n);x+=(p[0]-x)*a;y+=(p[1]-y)*a;z+=(p[2]-z)*a;r+=(((color>>16)&255)-r)*a;g+=(((color>>8)&255)-g)*a;b+=((color&255)-b)*a;}
    }
    static final class Store {
        final LinkedHashMap<Long,Voxel> voxels=new LinkedHashMap<>();
        // Triangle soup: observed depth patches only; no hole filling or watertight inference.
        float[] mx=new float[TRI_LIMIT*9];byte[] mc=new byte[TRI_LIMIT*12];int triangles;
        synchronized void clear(){voxels.clear();triangles=0;}
        synchronized int count(){return voxels.size();}
        synchronized int triCount(){return triangles;}
        synchronized void point(float[] p,int c){if(!valid(p))return;long k=key(p);Voxel v=voxels.get(k);if(v!=null)v.add(p,c);else if(voxels.size()<POINT_LIMIT)voxels.put(k,new Voxel(p,c));}
        synchronized void triangle(float[] a,float[] b,float[] c,int ca,int cb,int cc){if(triangles>=TRI_LIMIT||!valid(a)||!valid(b)||!valid(c)||!connect(a,b,c))return;int i=triangles*9,j=triangles*12;System.arraycopy(a,0,mx,i,3);System.arraycopy(b,0,mx,i+3,3);System.arraycopy(c,0,mx,i+6,3);color(mc,j,ca);color(mc,j+4,cb);color(mc,j+8,cc);triangles++;}
        synchronized Model snapshot(boolean mesh){if(mesh){return new Model(Arrays.copyOf(mx,triangles*9),Arrays.copyOf(mc,triangles*12),null);}float[] xyz=new float[voxels.size()*3];byte[] rgba=new byte[voxels.size()*4];int i=0;for(Voxel v:voxels.values()){xyz[3*i]=v.x;xyz[3*i+1]=v.y;xyz[3*i+2]=v.z;color(rgba,4*i,((int)v.r<<16)|((int)v.g<<8)|(int)v.b);i++;}return new Model(xyz,rgba,null);}
    }
    static boolean valid(float[] p){return p!=null&&Float.isFinite(p[0])&&Float.isFinite(p[1])&&Float.isFinite(p[2])&&Math.abs(p[0])<100&&Math.abs(p[1])<100&&Math.abs(p[2])<100;}
    static long key(float[] p){long a=(long)Math.floor(p[0]/VOXEL)+32768,b=(long)Math.floor(p[1]/VOXEL)+32768,c=(long)Math.floor(p[2]/VOXEL)+32768;return(a<<32)|(b<<16)|c;}
    static float dist2(float[] a,float[] b){float x=a[0]-b[0],y=a[1]-b[1],z=a[2]-b[2];return x*x+y*y+z*z;}
    static boolean connect(float[] a,float[] b,float[] c){return dist2(a,b)<.13f*.13f&&dist2(a,c)<.13f*.13f&&dist2(b,c)<.13f*.13f;}
    static void color(byte[] out,int i,int c){out[i]=(byte)(c>>16);out[i+1]=(byte)(c>>8);out[i+2]=(byte)c;out[i+3]=(byte)255;}
    static int clip(float v){return Math.max(0,Math.min(255,Math.round(v)));}
    static int rgb(int y,int u,int v){float l=1.164f*(y-16);return (clip(l+1.596f*(v-128))<<16)|(clip(l-.392f*(u-128)-.813f*(v-128))<<8)|clip(l+2.017f*(u-128));}
    static float[] unproject(float x,float y,float depth,float fx,float fy,float cx,float cy){return new float[]{(x-cx)*depth/fx,-(y-cy)*depth/fy,-depth};}
    static float[] bounds(Model m){float[] b={Float.POSITIVE_INFINITY,Float.POSITIVE_INFINITY,Float.POSITIVE_INFINITY,Float.NEGATIVE_INFINITY,Float.NEGATIVE_INFINITY,Float.NEGATIVE_INFINITY};for(int i=0;i<m.xyz.length;i++) {int j=i%3;b[j]=Math.min(b[j],m.xyz[i]);b[j+3]=Math.max(b[j+3],m.xyz[i]);}return b;}
    static void ply(Model m,OutputStream out)throws IOException{String h="ply\nformat binary_little_endian 1.0\ncomment KCSI ARCore depth voxel points (raw confidence-filtered or dense fallback; possible gray samples); not validated for measurement\nelement vertex "+m.size()+"\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n";out.write(h.getBytes(java.nio.charset.StandardCharsets.US_ASCII));ByteBuffer b=ByteBuffer.allocate(15).order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<m.size();i++){b.clear();b.putFloat(m.xyz[3*i]).putFloat(m.xyz[3*i+1]).putFloat(m.xyz[3*i+2]).put(m.rgba,4*i,3);out.write(b.array());}}
    static void glb(Model m,boolean mesh,OutputStream out)throws IOException{if(m.size()==0)throw new IOException("No geometry");int n=m.size(),pbytes=n*12,cbytes=n*4,bin=pbytes+cbytes;float[] b=bounds(m);String json=String.format(Locale.US,"{\"asset\":{\"version\":\"2.0\",\"generator\":\"KCSI Scene Scan experimental ARCore depth\"},\"scene\":0,\"scenes\":[{\"nodes\":[0]}],\"nodes\":[{\"mesh\":0}],\"meshes\":[{\"primitives\":[{\"attributes\":{\"POSITION\":0,\"COLOR_0\":1},\"mode\":%d,\"material\":0}]}],\"materials\":[{\"doubleSided\":true,\"extensions\":{\"KHR_materials_unlit\":{}},\"pbrMetallicRoughness\":{\"metallicFactor\":0,\"roughnessFactor\":1}}],\"extensionsUsed\":[\"KHR_materials_unlit\"],\"buffers\":[{\"byteLength\":%d}],\"bufferViews\":[{\"buffer\":0,\"byteOffset\":0,\"byteLength\":%d,\"target\":34962},{\"buffer\":0,\"byteOffset\":%d,\"byteLength\":%d,\"target\":34962}],\"accessors\":[{\"bufferView\":0,\"componentType\":5126,\"count\":%d,\"type\":\"VEC3\",\"min\":[%s,%s,%s],\"max\":[%s,%s,%s]},{\"bufferView\":1,\"componentType\":5121,\"normalized\":true,\"count\":%d,\"type\":\"VEC4\"}]}",mesh?4:0,bin,pbytes,pbytes,cbytes,n,b[0],b[1],b[2],b[3],b[4],b[5],n);byte[] j=json.getBytes(java.nio.charset.StandardCharsets.UTF_8);int jp=(j.length+3)&~3;ByteBuffer h=ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN);h.putInt(0x46546c67).putInt(2).putInt(12+8+jp+8+bin).putInt(jp).putInt(0x4e4f534a);out.write(h.array());out.write(j);for(int i=j.length;i<jp;i++)out.write(32);ByteBuffer bh=ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);bh.putInt(bin).putInt(0x004e4942);out.write(bh.array());ByteBuffer buf=ByteBuffer.allocate(pbytes).order(ByteOrder.LITTLE_ENDIAN);buf.asFloatBuffer().put(m.xyz);out.write(buf.array());out.write(m.rgba);}
}
