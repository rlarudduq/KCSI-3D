package kr.kcsi.scenescan;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import com.google.ar.core.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CAM=20, SAVE_PLY=21,SAVE_GLB=22;
    GLSurfaceView gl; ScanRenderer renderer; Session session; boolean installRequested=false,resumed=false,review=false,scanning=false,captureStarted=false,ready=false,exporting=false;
    TextView status,description; Button start,finish,points,mesh,savePly,saveGlb; LinearLayout reviewBar,captureBar; boolean overlayEnabled=true; String diagnostic="초기화 중";
    Geometry.Model pending; boolean pendingMesh; long lastError=0;
    float previousX,previousY; boolean pinching=false;
    int bg=Color.rgb(17,27,42),muted=Color.rgb(171,192,211),ink=Color.rgb(235,245,250);
    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);buildUI();immersive();}
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
    Button button(String s,Runnable fn){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setOnClickListener(v->fn.run());return b;}
    void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
    @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus)immersive();}
    android.graphics.drawable.GradientDrawable rounded(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(18));return d;}
    Button pill(String name,Runnable fn){Button b=button(name,fn);b.setTextColor(Color.WHITE);b.setBackground(rounded(0xd9233444));b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(dp(44));b.setMinimumHeight(dp(44));b.setPadding(dp(14),0,dp(14),0);return b;}
    void buildUI(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(bg);
        gl=new GLSurfaceView(this);gl.setEGLContextClientVersion(2);gl.setEGLConfigChooser(8,8,8,8,16,0);gl.setPreserveEGLContextOnPause(true);renderer=new ScanRenderer(this);gl.setRenderer(renderer);gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);root.addView(gl,new FrameLayout.LayoutParams(-1,-1));
        ScaleGestureDetector scale=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector d){float factor=d.getScaleFactor();if(review&&Float.isFinite(factor)&&factor>0)gl.queueEvent(()->renderer.scale(factor));return true;}});gl.setOnTouchListener((v,e)->{if(!review)return true;scale.onTouchEvent(e);int a=e.getActionMasked();if(a==MotionEvent.ACTION_DOWN){previousX=e.getX();previousY=e.getY();pinching=false;}else if(a==MotionEvent.ACTION_POINTER_DOWN||e.getPointerCount()>1){pinching=true;}else if(a==MotionEvent.ACTION_MOVE&&e.getPointerCount()==1){float x=e.getX(),y=e.getY();if(!pinching&&!scale.isInProgress()){float dx=x-previousX,dy=y-previousY;gl.queueEvent(()->renderer.rotate(dx,dy));}previousX=x;previousY=y;pinching=false;}return true;});
        // Controls float over the full camera surface, instead of reserving vertical space.
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.TOP);top.setPadding(dp(16),dp(8),dp(16),0);
        LinearLayout hud=new LinearLayout(this);hud.setOrientation(LinearLayout.VERTICAL);hud.setBackground(rounded(0xb51a2532));hud.setPadding(dp(10),dp(6),dp(10),dp(6));
        status=text("v0.6 · 카메라 준비 중",12,ink);status.setMaxLines(2);hud.addView(status);description=text("깊이 0 · 점 0 · 면 0",11,0xffb7e9dc);hud.addView(description);TextView legend=text("노랑: 추적 · 청록: 깊이",10,0xffe4e9ef);hud.addView(legend);
        top.addView(hud,new LinearLayout.LayoutParams(dp(250),-2));top.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));Button more=pill("⋯",()->showMenu());more.setContentDescription("설정 및 촬영 진단");LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(48),dp(44));mp.leftMargin=dp(8);top.addView(more,mp);root.addView(top,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));
        // Right-centre floating controls. Physical right edge, independent of layout direction.
        captureBar=new LinearLayout(this);captureBar.setOrientation(LinearLayout.VERTICAL);captureBar.setGravity(Gravity.CENTER_HORIZONTAL);
        start=pill("● 시작",()->toggleCapture());start.setTextSize(15);start.setPadding(dp(5),0,dp(5),0);captureBar.addView(start,new LinearLayout.LayoutParams(dp(86),dp(60)));
        finish=pill("종료 / 3D",()->finishCapture());finish.setTextSize(12);finish.setPadding(dp(3),0,dp(3),0);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(76),dp(44));fp.topMargin=dp(8);captureBar.addView(finish,fp);
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.CENTER_VERTICAL);sp.rightMargin=dp(14);root.addView(captureBar,sp);
        reviewBar=new LinearLayout(this);reviewBar.setGravity(Gravity.CENTER);reviewBar.setOrientation(LinearLayout.HORIZONTAL);reviewBar.setPadding(dp(8),0,dp(8),0);
        points=pill("점군",()->{gl.queueEvent(()->renderer.setMesh(false));status.setText("3D 점군 · 깊이 추정");});mesh=pill("표면",()->{gl.queueEvent(()->renderer.setMesh(true));status.setText("3D 표면 · 실험용");});savePly=pill("PLY",()->save(false));saveGlb=pill("GLB",()->save(true));Button reset=pill("다시 촬영",()->resetConfirm());for(Button b:new Button[]{points,mesh,savePly,saveGlb,reset}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(44));lp.setMargins(dp(3),0,dp(3),0);reviewBar.addView(b,lp);}
        FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);rp.bottomMargin=dp(10);root.addView(reviewBar,rp);setContentView(root);buttons();
    }
    void toggleCapture(){
        if(!ready||review||exporting)return;
        if(scanning){scanning=false;gl.queueEvent(()->renderer.pauseCapture());status.setText("촬영 일시중지");buttons();return;}
        scanning=true;
        if(!captureStarted){captureStarted=true;description.setText("깊이 0 · 점 0 · 면 0");gl.queueEvent(()->renderer.start());}
        else gl.queueEvent(()->renderer.resumeCapture());
        status.setText("● 촬영 중 · 천천히 이동");buttons();
    }
    void finishCapture(){
        if(!ready||review||exporting||!captureStarted)return;
        if(renderer.store.count()==0&&renderer.store.triCount()==0){new AlertDialog.Builder(this).setTitle("아직 3D 데이터가 없습니다").setMessage("카메라를 30~50cm 옆으로 천천히 이동해 주세요. 진단에서 추적과 깊이 상태를 확인할 수 있습니다.").setNegativeButton("계속 촬영",(d,w)->{if(!scanning)toggleCapture();}).setNeutralButton("진단",(d,w)->showDiagnostic()).setPositiveButton("촬영 중단",(d,w)->{scanning=captureStarted=false;gl.queueEvent(()->renderer.reset());status.setText("촬영 중단 · 다시 시작 가능");description.setText("깊이 0 · 점 0 · 면 0");buttons();}).show();return;}
        scanning=false;captureStarted=false;review=true;gl.queueEvent(()->renderer.stop());status.setText("3D 보기 · 추정 깊이 (비계측)");buttons();
    }
    void resetConfirm(){new AlertDialog.Builder(this).setMessage("현재 모델을 지우고 새로 촬영할까요?").setNegativeButton("취소",null).setPositiveButton("초기화",(d,w)->{scanning=review=captureStarted=false;gl.queueEvent(()->renderer.reset());status.setText("새 촬영 준비");description.setText("깊이 0 · 점 0 · 면 0");buttons();}).show();}
    void showMenu(){String[] items={"촬영 진단 / 버전",overlayEnabled?"실시간 점 표시 끄기":"실시간 점 표시 켜기","초기화"};new AlertDialog.Builder(this).setTitle("KCSI Scene Scan v0.6").setItems(items,(d,i)->{if(i==0)showDiagnostic();else if(i==1){overlayEnabled=!overlayEnabled;boolean value=overlayEnabled;gl.queueEvent(()->renderer.liveOverlay=value);}else if(!exporting)resetConfirm();}).show();}
    void showDiagnostic(){String detail=diagnostic;new AlertDialog.Builder(this).setTitle("촬영 진단 · v0.6").setMessage(detail+"\n\n촬영 화면: 노란 점은 AR 추적 특징점, 청록 점은 채택된 깊이 점입니다. 노란 점과 검출 평면은 모델 저장에 포함하지 않습니다.\n3D 보기: 원래 색상으로 표시합니다. 회색 점은 RGB를 받지 못한 깊이 샘플일 수 있습니다. 일반 Depth는 보간된 추정값입니다. 정밀 SfM/측량용이 아닙니다.\n실내에서 깊이 중앙값이 8m를 넘거나 이동이 10m를 넘으면 현재 스캔을 종료하고 앱을 완전히 닫은 뒤 재시험하세요.").setNegativeButton("닫기",null).setPositiveButton("복사",(d,w)->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("KCSI diagnostics",detail));Toast.makeText(this,"진단 복사 완료",Toast.LENGTH_SHORT).show();}).show();}
    int displayRotation(){return getWindowManager().getDefaultDisplay().getRotation();}
    void buttons(){
        start.setText(scanning?"Ⅱ 중지":captureStarted?"▶ 재개":"● 시작");start.setContentDescription(scanning?"촬영 일시중지":captureStarted?"촬영 재개":"촬영 시작");start.setBackground(rounded(scanning?0xe0ba4545:0xe01c807c));start.setEnabled(ready&&!review&&!exporting);
        finish.setEnabled(ready&&captureStarted&&!review&&!exporting);finish.setAlpha(finish.isEnabled()?1f:.45f);finish.setContentDescription("촬영 종료 및 3D 모델 보기");captureBar.setVisibility(review?View.GONE:View.VISIBLE);
        reviewBar.setVisibility(review?View.VISIBLE:View.GONE);points.setEnabled(review&&!exporting&&renderer.store.count()>0);mesh.setEnabled(review&&!exporting&&renderer.store.triCount()>0);savePly.setEnabled(review&&!exporting&&renderer.store.count()>0);saveGlb.setEnabled(review&&!exporting&&renderer.store.triCount()>0);
    }
    @Override protected void onResume(){super.onResume();resumeAR();}
    void resumeAR(){if(resumed)return;if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},CAM);return;}
        try {if(session==null){if(ArCoreApk.getInstance().requestInstall(this,!installRequested)==ArCoreApk.InstallStatus.INSTALL_REQUESTED){installRequested=true;status.setText("Google Play AR 서비스 설치 또는 업데이트 필요");return;}session=new Session(this);if(!session.isDepthModeSupported(Config.DepthMode.AUTOMATIC)){status.setText("이 기기는 ARCore Depth API를 지원하지 않습니다.");session.close();session=null;return;}Config config=session.getConfig();config.setDepthMode(Config.DepthMode.AUTOMATIC);config.setFocusMode(Config.FocusMode.AUTO);config.setPlaneFindingMode(Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL);config.setUpdateMode(Config.UpdateMode.LATEST_CAMERA_IMAGE);session.configure(config);}
            session.resume();renderer.session=session;gl.onResume();resumed=true;ready=true;buttons();status.setText("Depth 지원 확인 · 카메라 준비 완료");
        }catch(Exception e){ready=false;buttons();diagnostic="ARCore 시작 실패: "+e.toString();status.setText("ARCore 시작 실패 · ⋯ 진단 확인");}
    }
    @Override protected void onPause(){ready=false;buttons();if(resumed){gl.onPause();session.pause();resumed=false;}super.onPause();}
    @Override protected void onDestroy(){if(session!=null){session.close();session=null;}super.onDestroy();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==CAM){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)resumeAR();else status.setText("카메라 권한이 필요합니다. 설정에서 허용하세요.");}}
    void status(String text,int frames,int nums,int tris,boolean rec,String diag){runOnUiThread(()->{diagnostic=diag;if(!review && (!scanning || rec)){status.setText(captureStarted&&!scanning?"촬영 일시중지":(rec?"● ":"")+text);description.setText("깊이 "+frames+" · 점 "+nums+" · 면 "+tris);}});}
    void renderError(Exception e){android.util.Log.e("KCSI-SceneScan","ARCore/renderer error",e);long now=android.os.SystemClock.elapsedRealtime();if(now-lastError<1000)return;lastError=now;runOnUiThread(()->{scanning=false;buttons();diagnostic="렌더링 오류: "+e.toString()+"\n"+diagnostic;status.setText("연산 오류 · ⋯ 진단 확인");});}
    void save(boolean isMesh){if(exporting||!review)return;Geometry.Model m=renderer.store.snapshot(isMesh);if(m.size()==0){Toast.makeText(this,"저장할 데이터가 없습니다. 추가 촬영 후 다시 시도하세요.",Toast.LENGTH_LONG).show();return;}pending=m;pendingMesh=isMesh;exporting=true;buttons();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(isMesh?"model/gltf-binary":"application/octet-stream");String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());i.putExtra(Intent.EXTRA_TITLE,"KCSI_"+stamp+(isMesh?"_depth_preview.glb":"_depth_points.ply"));try{startActivityForResult(i,isMesh?SAVE_GLB:SAVE_PLY);}catch(Exception e){exporting=false;pending=null;buttons();Toast.makeText(this,"저장 위치 선택 실패",Toast.LENGTH_LONG).show();}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=SAVE_GLB&&request!=SAVE_PLY)return;Geometry.Model m=pending;boolean isMesh=pendingMesh;pending=null;if(result!=RESULT_OK||data==null||data.getData()==null||m==null){exporting=false;buttons();return;}Uri uri=data.getData();new Thread(()->{String msg;try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new IOException("Output unavailable");BufferedOutputStream b=new BufferedOutputStream(out);if(isMesh)Geometry.glb(m,true,b);else Geometry.ply(m,b);b.flush();msg="저장 완료";}catch(Exception e){msg="저장 실패: "+e.getMessage();}String finalMsg=msg;runOnUiThread(()->{exporting=false;buttons();Toast.makeText(this,finalMsg,Toast.LENGTH_LONG).show();});},"export-model").start();}
}
