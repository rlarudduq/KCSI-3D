package kr.kcsi.scenescan;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import com.google.ar.core.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CAM=20, SAVE_PLY=21,SAVE_GLB=22;
    GLSurfaceView gl; ScanRenderer renderer; Session session; boolean installRequested=false,resumed=false,review=false,scanning=false,ready=false,exporting=false;
    TextView status,description; Button start,finish,reset,points,mesh,savePly,saveGlb; CheckBox overlay;
    Geometry.Model pending; boolean pendingMesh; long lastError=0;
    float previousX,previousY; boolean pinching=false;
    int bg=Color.rgb(17,27,42),muted=Color.rgb(171,192,211),ink=Color.rgb(235,245,250);
    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);buildUI();}
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
    Button button(String s,Runnable fn){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setOnClickListener(v->fn.run());return b;}
    void buildUI(){LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(bg);LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.HORIZONTAL);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(12),dp(6),dp(12),dp(6));TextView title=text("KCSI Scene Scan  /  v0.1",19,ink);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));TextView chip=text("ARCore 실험 · 오프라인",13,0xff63dfc9);header.addView(chip);layout.addView(header);
        status=text("카메라와 ARCore 준비 중…",14,ink);status.setPadding(dp(12),dp(2),dp(12),dp(5));layout.addView(status);
        gl=new GLSurfaceView(this);gl.setEGLContextClientVersion(2);gl.setEGLConfigChooser(8,8,8,8,16,0);gl.setPreserveEGLContextOnPause(true);renderer=new ScanRenderer(this);gl.setRenderer(renderer);gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);layout.addView(gl,new LinearLayout.LayoutParams(-1,0,1));
        ScaleGestureDetector scale=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector d){float factor=d.getScaleFactor();if(review&&Float.isFinite(factor)&&factor>0)gl.queueEvent(()->renderer.scale(factor));return true;}});gl.setOnTouchListener((v,e)->{if(!review)return true;scale.onTouchEvent(e);int a=e.getActionMasked();if(a==MotionEvent.ACTION_DOWN){previousX=e.getX();previousY=e.getY();pinching=false;}else if(a==MotionEvent.ACTION_POINTER_DOWN||e.getPointerCount()>1){pinching=true;}else if(a==MotionEvent.ACTION_MOVE&&e.getPointerCount()==1){float x=e.getX(),y=e.getY();if(!pinching&&!scale.isInProgress()){float dx=x-previousX,dy=y-previousY;gl.queueEvent(()->renderer.rotate(dx,dy));}previousX=x;previousY=y;pinching=false;}return true;});
        description=text("천천히 옆으로 이동하면서 벽·바닥·장비를 여러 방향에서 촬영하세요.",12,muted);description.setPadding(dp(12),dp(4),dp(12),dp(3));layout.addView(description);
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setFillViewport(true);LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL);controls.setPadding(dp(4),0,dp(4),0);scroll.addView(controls);
        start=button("촬영 시작",()->{if(!ready)return;scanning=true;review=false;gl.queueEvent(()->renderer.start());description.setText("천천히 이동하세요. 점이 부족한 면은 다른 각도에서 추가 촬영하세요.");buttons();});
        finish=button("촬영 종료 / 3D",()->{scanning=false;review=true;gl.queueEvent(()->renderer.stop());description.setText("드래그 회전 · 두 손가락 확대. 표면은 추정 깊이 패치이며 정밀 메시가 아닙니다.");status.setText("촬영 종료 · 3D 보기");buttons();});
        reset=button("초기화",()->new AlertDialog.Builder(this).setMessage("현재 미저장 모델을 지우고 새로 촬영할까요?").setNegativeButton("취소",null).setPositiveButton("초기화",(d,w)->{scanning=review=false;gl.queueEvent(()->renderer.reset());description.setText("새 장면을 촬영할 수 있습니다.");buttons();}).show());
        points=button("점군",()->{gl.queueEvent(()->renderer.setMesh(false));description.setText("Raw Depth 신뢰도 필터 + 약 3.5cm 복셀 평균 컬러 점군");});mesh=button("표면(실험)",()->{gl.queueEvent(()->renderer.setMesh(true));description.setText("밀집 Depth 추정값에서 연결한 국소 삼각형 · 중복 표면/빈 영역 가능 · 미측정 모델");});
        savePly=button("PLY 저장",()->save(false));saveGlb=button("GLB 표면 저장",()->save(true));overlay=new CheckBox(this);overlay.setText("실시간 점 표시");overlay.setTextColor(muted);overlay.setChecked(true);overlay.setOnCheckedChangeListener((b,c)->gl.queueEvent(()->renderer.liveOverlay=c));
        for(View v:new View[]{start,finish,reset,points,mesh,savePly,saveGlb,overlay})controls.addView(v);layout.addView(scroll);setContentView(layout);buttons();
    }
    int displayRotation(){return getWindowManager().getDefaultDisplay().getRotation();}
    void buttons(){start.setEnabled(ready&&!scanning&&!review&&!exporting);finish.setEnabled(scanning&&!exporting);reset.setEnabled(ready&&!exporting);points.setEnabled(review&&!exporting);mesh.setEnabled(review&&!exporting);savePly.setEnabled(review&&!exporting);saveGlb.setEnabled(review&&!exporting);}
    @Override protected void onResume(){super.onResume();resumeAR();}
    void resumeAR(){if(resumed)return;if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},CAM);return;}
        try {if(session==null){if(ArCoreApk.getInstance().requestInstall(this,!installRequested)==ArCoreApk.InstallStatus.INSTALL_REQUESTED){installRequested=true;status.setText("Google Play AR 서비스 설치 또는 업데이트 필요");return;}session=new Session(this);if(!session.isDepthModeSupported(Config.DepthMode.AUTOMATIC)){status.setText("이 기기는 ARCore Depth API를 지원하지 않습니다.");session.close();session=null;return;}Config config=session.getConfig();config.setDepthMode(Config.DepthMode.AUTOMATIC);config.setFocusMode(Config.FocusMode.AUTO);config.setPlaneFindingMode(Config.PlaneFindingMode.DISABLED);config.setUpdateMode(Config.UpdateMode.LATEST_CAMERA_IMAGE);session.configure(config);}
            session.resume();renderer.session=session;gl.onResume();resumed=true;ready=true;buttons();status.setText("Depth 지원 확인 · 카메라 준비 완료");
        }catch(Exception e){ready=false;buttons();status.setText("ARCore 시작 실패: "+e.getClass().getSimpleName()+" / "+e.getMessage());}
    }
    @Override protected void onPause(){if(resumed){gl.onPause();session.pause();resumed=false;}super.onPause();}
    @Override protected void onDestroy(){if(session!=null){session.close();session=null;}super.onDestroy();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==CAM){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)resumeAR();else status.setText("카메라 권한이 필요합니다. 설정에서 허용하세요.");}}
    void status(String text,int frames,int nums,int tris,boolean rec){runOnUiThread(()->{if(!review){status.setText(text+"  |  깊이 프레임 "+frames+"  |  점 "+nums+"  |  삼각형 "+tris+(rec?"  ● 촬영 중":""));}});}
    void renderError(Exception e){long now=android.os.SystemClock.elapsedRealtime();if(now-lastError<1000)return;lastError=now;runOnUiThread(()->{scanning=false;buttons();status.setText("연산 오류: "+e.getClass().getSimpleName()+" / "+e.getMessage());});}
    void save(boolean isMesh){if(exporting||!review)return;Geometry.Model m=renderer.store.snapshot(isMesh);if(m.size()==0){Toast.makeText(this,"저장할 데이터가 없습니다. 추가 촬영 후 다시 시도하세요.",Toast.LENGTH_LONG).show();return;}pending=m;pendingMesh=isMesh;exporting=true;buttons();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(isMesh?"model/gltf-binary":"application/octet-stream");String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());i.putExtra(Intent.EXTRA_TITLE,"KCSI_"+stamp+(isMesh?"_depth_preview.glb":"_raw_points.ply"));try{startActivityForResult(i,isMesh?SAVE_GLB:SAVE_PLY);}catch(Exception e){exporting=false;pending=null;buttons();Toast.makeText(this,"저장 위치 선택 실패",Toast.LENGTH_LONG).show();}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=SAVE_GLB&&request!=SAVE_PLY)return;Geometry.Model m=pending;boolean isMesh=pendingMesh;pending=null;if(result!=RESULT_OK||data==null||data.getData()==null||m==null){exporting=false;buttons();return;}Uri uri=data.getData();new Thread(()->{String msg;try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new IOException("Output unavailable");BufferedOutputStream b=new BufferedOutputStream(out);if(isMesh)Geometry.glb(m,true,b);else Geometry.ply(m,b);b.flush();msg="저장 완료";}catch(Exception e){msg="저장 실패: "+e.getMessage();}String finalMsg=msg;runOnUiThread(()->{exporting=false;buttons();Toast.makeText(this,finalMsg,Toast.LENGTH_LONG).show();});},"export-model").start();}
}
