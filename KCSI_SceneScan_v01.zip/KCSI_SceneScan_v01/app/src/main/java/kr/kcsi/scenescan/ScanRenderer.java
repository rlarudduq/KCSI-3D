package kr.kcsi.scenescan;

import android.media.Image;
import android.opengl.*;
import android.os.SystemClock;
import com.google.ar.core.*;
import com.google.ar.core.exceptions.NotYetAvailableException;
import java.nio.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

final class ScanRenderer implements GLSurfaceView.Renderer {
    final MainActivity activity; final Geometry.Store store=new Geometry.Store();
    volatile Session session; int width=1,height=1,texture,background,program;
    boolean recording=false,review=false,mesh=false,liveOverlay=true;
    int frames=0,meshFrames=0,rawReads=0,denseReads=0,rgbReads=0,rgbMisses=0,rawAttempts=0,denseAttempts=0,trackedUpdates=0,featureCount=0,densePointFrames=0,grayFrames=0;
    long updates=0,lastFeatureCheck=0,lastRaw=-1,lastCapture=0,lastMesh=0,lastUi=0,lastBuffer=0,lastDenseTimestamp=-1; String rawState="미시도",denseState="미시도",rgbState="미시도",tracking="대기",lastStreamError="없음";
    Session boundSession; int boundTexture=-1,displayW=-1,displayH=-1,displayRot=-1; Pose lastPose=null,lastSurfacePose=null;
    float yaw=.7f,pitch=.65f,zoom=1f; float[] center={0,0,0};float radius=2;
    FloatBuffer positions; ByteBuffer colors;
    FloatBuffer featurePositions; ByteBuffer featureColors; int featureDrawCount=0,planeCount=0; long featureTimestamp=-1;
    String featureState="대기",rawStats="미취득",denseStats="미취득"; float maxTravel=0; Pose firstPose;
    final float[] neutralTint={1,1,1,1},depthTint={.10f,1f,.78f,1},featureTint={1f,.76f,.13f,1}; int count=0,drawMode=GLES20.GL_POINTS; boolean dirty=true;
    final float[] quad={-1,-1,1,-1,-1,1,1,1}; final FloatBuffer quadBuf=fb(quad),uvBuf=fb(new float[8]);
    ScanRenderer(MainActivity a){activity=a;}
    static FloatBuffer fb(float[] f){FloatBuffer b=ByteBuffer.allocateDirect(f.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(f).position(0);return b;}
    static int shader(int type,String s){int id=GLES20.glCreateShader(type);GLES20.glShaderSource(id,s);GLES20.glCompileShader(id);int[] ok=new int[1];GLES20.glGetShaderiv(id,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)throw new IllegalStateException(GLES20.glGetShaderInfoLog(id));return id;}
    static int program(String v,String f){int a=shader(GLES20.GL_VERTEX_SHADER,v),b=shader(GLES20.GL_FRAGMENT_SHADER,f),p=GLES20.glCreateProgram();GLES20.glAttachShader(p,a);GLES20.glAttachShader(p,b);GLES20.glLinkProgram(p);int[] ok=new int[1];GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);GLES20.glDeleteShader(a);GLES20.glDeleteShader(b);if(ok[0]==0)throw new IllegalStateException(GLES20.glGetProgramInfoLog(p));return p;}
    public void onSurfaceCreated(GL10 gl,EGLConfig c){int[] t=new int[1];GLES20.glGenTextures(1,t,0);texture=t[0];GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
        background=program("attribute vec2 aPos;attribute vec2 aUV;varying vec2 vUV;void main(){gl_Position=vec4(aPos,0.,1.);vUV=aUV;}","#extension GL_OES_EGL_image_external : require\nprecision mediump float;varying vec2 vUV;uniform samplerExternalOES tex;void main(){gl_FragColor=texture2D(tex,vUV);}");
        program=program("attribute vec3 aPos;attribute vec4 aColor;uniform mat4 mvp;uniform float pt;uniform vec4 tint;uniform float useTint;varying vec4 vColor;void main(){gl_Position=mvp*vec4(aPos,1.);gl_PointSize=pt;vColor=mix(aColor,tint,useTint);}","precision mediump float;varying vec4 vColor;void main(){gl_FragColor=vColor;}");dirty=true;boundTexture=-1;displayW=-1;
    }
    public void onSurfaceChanged(GL10 gl,int w,int h){width=Math.max(1,w);height=Math.max(1,h);GLES20.glViewport(0,0,width,height);}
    void start(){store.clear();resetCounters();recording=true;review=false;mesh=false;lastPose=lastSurfacePose=null;lastCapture=lastMesh=0;dirty=true;}
    void pauseCapture(){recording=false;}
    void resumeCapture(){recording=true;lastPose=lastSurfacePose=null;lastCapture=lastMesh=0;}
    void resetCounters(){frames=meshFrames=rawReads=denseReads=rgbReads=rgbMisses=rawAttempts=denseAttempts=trackedUpdates=densePointFrames=grayFrames=0;lastRaw=lastDenseTimestamp=-1;rawState=denseState=rgbState="대기";lastStreamError="없음";rawStats=denseStats="미취득";firstPose=null;maxTravel=0;}
    String diag(){return "카메라 업데이트: "+updates+"\n추적: "+tracking+" / 촬영 중 추적 "+trackedUpdates+"회\nAR 특징점(노란색): "+featureCount+" / "+featureState+"\n인식 평면: "+planeCount+" / 이동 최대: "+String.format(java.util.Locale.US,"%.2f m",maxTravel)+"\nRaw Depth: "+rawState+"\nRaw 픽셀 진단: "+rawStats+"\nRaw 요청/획득/점 채택: "+rawAttempts+" / "+rawReads+" / "+frames+"\n일반 Depth: "+denseState+"\n일반 픽셀 진단: "+denseStats+"\n일반 요청/획득/표면 채택: "+denseAttempts+" / "+denseReads+" / "+meshFrames+"\n일반 Depth 점 추가 프레임: "+densePointFrames+"\nRGB: "+rgbState+" (성공 "+rgbReads+", 대기 "+rgbMisses+")\nRGB 미사용 채택 프레임: "+grayFrames+"\n점 "+store.count()+" / 삼각형 "+store.triCount()+"\n최근 예외: "+lastStreamError;}
    void streamError(String name,Exception e){lastStreamError=name+": "+e.getClass().getSimpleName()+" / "+String.valueOf(e.getMessage());android.util.Log.e("KCSI-SceneScan",lastStreamError,e);}
    void stop(){recording=false;review=true;mesh=store.triCount()>0;fit();dirty=true;activity.status("3D 보기",frames+meshFrames,store.count(),store.triCount(),false,diag());}
    void reset(){store.clear();resetCounters();lastPose=lastSurfacePose=null;lastCapture=lastMesh=0;recording=false;review=false;mesh=false;dirty=true;}
    void fit(){Geometry.Model m=store.snapshot(false);if(m.size()==0)m=store.snapshot(true);if(m.size()==0)return;float[] b=Geometry.bounds(m);for(int i=0;i<3;i++)center[i]=(b[i]+b[i+3])/2;radius=Math.max(.4f,(float)Math.sqrt(Math.pow(b[3]-b[0],2)+Math.pow(b[4]-b[1],2)+Math.pow(b[5]-b[2],2))/2);zoom=1;}
    void setMesh(boolean v){mesh=v;dirty=true;}
    void rotate(float dx,float dy){yaw+=dx*.008f;pitch=Math.max(-1.45f,Math.min(1.45f,pitch+dy*.008f));}
    void scale(float factor){zoom=Math.max(.25f,Math.min(5f,zoom/factor));}
    void refresh(boolean useMesh){Geometry.Model m=store.snapshot(useMesh);positions=fb(m.xyz);colors=ByteBuffer.allocateDirect(m.rgba.length);colors.put(m.rgba).position(0);count=m.size();drawMode=useMesh?GLES20.GL_TRIANGLES:GLES20.GL_POINTS;dirty=false;lastBuffer=SystemClock.elapsedRealtime();}
    public void onDrawFrame(GL10 gl){GLES20.glClearColor(.043f,.075f,.11f,1);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);long now=SystemClock.elapsedRealtime();
        if(review){if(dirty)refresh(mesh);float[] view=new float[16],proj=new float[16],mvp=new float[16];float r=radius*2.8f*zoom;Matrix.setLookAtM(view,0,center[0]+r*(float)(Math.cos(pitch)*Math.sin(yaw)),center[1]+r*(float)Math.sin(pitch),center[2]+r*(float)(Math.cos(pitch)*Math.cos(yaw)),center[0],center[1],center[2],0,1,0);Matrix.perspectiveM(proj,0,50,width/(float)height,.025f,Math.max(50,radius*20));Matrix.multiplyMM(mvp,0,proj,0,view,0);drawModel(mvp,3.5f);return;}
        Session s=session;if(s==null)return;
        try{
            if(boundSession!=s||boundTexture!=texture){s.setCameraTextureName(texture);boundSession=s;boundTexture=texture;displayW=-1;}
            int rotation=activity.displayRotation();if(displayW!=width||displayH!=height||displayRot!=rotation){s.setDisplayGeometry(rotation,width,height);displayW=width;displayH=height;displayRot=rotation;}
            Frame frame=s.update();Camera cam=frame.getCamera();updates++;if(frame.getTimestamp()!=0)drawBackground(frame);
            boolean tracked=cam.getTrackingState()==TrackingState.TRACKING;tracking=tracked?"정상":cam.getTrackingState()+" / "+cam.getTrackingFailureReason();
            String state=tracked?(recording?"깊이 데이터 수집 중":"v0.5 · 촬영 준비"):"추적 대기 · 천천히 이동";
            if(tracked&&now-lastFeatureCheck>=180){lastFeatureCheck=now;updateFeatures(frame,s);}else if(!tracked){featureDrawCount=0;featureCount=0;featureState="추적 대기";}
            if(recording&&tracked&&frame.getTimestamp()!=0){trackedUpdates++;Pose pose=cam.getPose();if(firstPose==null)firstPose=pose;maxTravel=Math.max(maxTravel,(float)Math.sqrt(Geometry.dist2(firstPose.getTranslation(),pose.getTranslation())));boolean rawDue=now-lastCapture>=300&&moved(lastPose,pose,.05f,6);boolean meshDue=now-lastMesh>=700&&moved(lastSurfacePose,pose,.12f,12)&&store.triCount()<Geometry.TRI_LIMIT;
                if(rawDue||meshDue){Image rgb=null;try{rgb=frame.acquireCameraImage();rgbReads++;rgbState="정상";}catch(NotYetAvailableException e){rgbMisses++;rgbState="대기 (깊이와 독립 수집)";}catch(Exception e){rgbMisses++;rgbState="오류 (깊이와 독립 수집)";streamError("RGB",e);}
                    try{
                        if(rawDue){lastCapture=now;rawAttempts++;try(Image dep=frame.acquireRawDepthImage16Bits(); Image confidence=frame.acquireRawDepthConfidenceImage()){rawReads++;rawState=dep.getWidth()+"×"+dep.getHeight();if(dep.getTimestamp()!=lastRaw){int added=capture(frame,dep,confidence,rgb,false,true);if(added>0){lastRaw=dep.getTimestamp();frames++;lastPose=pose;dirty=true;if(rgb==null)grayFrames++;rawState+=" · 채택 "+added;}else rawState+=" · 유효점 없음";}else rawState+=" · 새 프레임 대기";}
                            catch(NotYetAvailableException e){rawState="아직 준비되지 않음";}catch(Exception e){rawState="오류 · 진단 참조";streamError("Raw Depth",e);}}
                        if(meshDue){lastMesh=now;denseAttempts++;try(Image dep=frame.acquireDepthImage16Bits()){denseReads++;denseState=dep.getWidth()+"×"+dep.getHeight();if(dep.getTimestamp()!=lastDenseTimestamp){boolean fallback=frames==0;int oldPoints=store.count();int added=capture(frame,dep,null,rgb,true,fallback);int newPoints=store.count()-oldPoints;if(added>0||newPoints>0){lastDenseTimestamp=dep.getTimestamp();meshFrames++;lastSurfacePose=pose;dirty=true;if(newPoints>0)densePointFrames++;if(rgb==null)grayFrames++;denseState+=" · 면 +"+added+" / 점 +"+newPoints;}else denseState+=" · 유효 표면 없음";}else denseState+=" · 새 프레임 대기";}
                            catch(NotYetAvailableException e){denseState="아직 준비되지 않음";}catch(Exception e){denseState="오류 · 진단 참조";streamError("일반 Depth",e);}}
                    }finally{if(rgb!=null)rgb.close();}
                }
                if(store.count()>0||store.triCount()>0)state="수집 중 · 천천히 이동";else state=featureCount==0?"특징점 없음 · 물체 쪽으로 이동":"특징점 추적 중 · 깊이 대기";
                if(rawState.contains("오류")||denseState.contains("오류"))state="깊이 오류 · ⋯ 진단 확인";
            }
            if(liveOverlay&&tracked){float[] view=new float[16],proj=new float[16],mvp=new float[16];cam.getViewMatrix(view,0);cam.getProjectionMatrix(proj,0,.05f,50f);Matrix.multiplyMM(mvp,0,proj,0,view,0);
                if(recording){if(dirty&&now-lastBuffer>=350)refresh(false);drawBuffers(mvp,7f,positions,colors,count,GLES20.GL_POINTS,depthTint,true);}
                drawBuffers(mvp,6f,featurePositions,featureColors,featureDrawCount,GLES20.GL_POINTS,featureTint,true);
            }
            if(!recording&&lastStreamError.startsWith("렌더링:"))state="연산 오류 · ⋯ 진단 확인";if(now-lastUi>=400){lastUi=now;activity.status(state+" · 추적점 "+featureCount,frames+meshFrames,store.count(),store.triCount(),recording,diag());}
        }catch(Exception e){recording=false;streamError("렌더링",e);activity.renderError(e);}
    }
    static boolean moved(Pose old,Pose next,float metres,float degrees){if(old==null)return true;float[] a=old.getTranslation(),b=next.getTranslation();if(Geometry.dist2(a,b)>=metres*metres)return true;float[] q=old.getRotationQuaternion(),r=next.getRotationQuaternion();double dot=Math.abs(q[0]*r[0]+q[1]*r[1]+q[2]*r[2]+q[3]*r[3]);return 2*Math.acos(Math.min(1,dot))*180/Math.PI>=degrees;}
    void drawBackground(Frame frame){float[] uv=new float[8];frame.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,quad,Coordinates2d.TEXTURE_NORMALIZED,uv);uvBuf.position(0);uvBuf.put(uv).position(0);GLES20.glDisable(GLES20.GL_DEPTH_TEST);GLES20.glDepthMask(false);GLES20.glUseProgram(background);GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glUniform1i(GLES20.glGetUniformLocation(background,"tex"),0);int p=GLES20.glGetAttribLocation(background,"aPos"),u=GLES20.glGetAttribLocation(background,"aUV");quadBuf.position(0);GLES20.glEnableVertexAttribArray(p);GLES20.glEnableVertexAttribArray(u);GLES20.glVertexAttribPointer(p,2,GLES20.GL_FLOAT,false,0,quadBuf);GLES20.glVertexAttribPointer(u,2,GLES20.GL_FLOAT,false,0,uvBuf);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);GLES20.glDisableVertexAttribArray(p);GLES20.glDisableVertexAttribArray(u);GLES20.glDepthMask(true);}
    void updateFeatures(Frame frame,Session s){
        com.google.ar.core.PointCloud pc=null;
        try{pc=frame.acquirePointCloud();
            FloatBuffer pts=pc.getPoints().duplicate();featureCount=pts.remaining()/4;
            if(featureCount==0){featureDrawCount=0;featureState="ARCore 반환 0개";return;}
            featureState="정상";
            if(pc.getTimestamp()==featureTimestamp&&featureDrawCount>0)return;
            featureTimestamp=pc.getTimestamp();int limit=Math.min(featureCount,6000);float[] xyz=new float[limit*3];byte[] rgba=new byte[limit*4];int n=0;
            for(int i=0;i<featureCount&&n<limit;i++){float x=pts.get(),y=pts.get(),z=pts.get(),confidence=pts.get();if(!Float.isFinite(x)||!Float.isFinite(y)||!Float.isFinite(z)||!Float.isFinite(confidence))continue;xyz[n*3]=x;xyz[n*3+1]=y;xyz[n*3+2]=z;Geometry.color(rgba,n*4,0xffc221);n++;}
            featurePositions=fb(java.util.Arrays.copyOf(xyz,n*3));featureColors=ByteBuffer.allocateDirect(n*4);featureColors.put(rgba,0,n*4).position(0);featureDrawCount=n;
        }catch(Exception e){featureCount=featureDrawCount=0;featureState=e.getClass().getSimpleName();streamError("AR 특징점",e);}
        finally{if(pc!=null)pc.release();try{int n=0;for(Plane p:s.getAllTrackables(Plane.class))if(p.getTrackingState()==TrackingState.TRACKING&&p.getSubsumedBy()==null)n++;planeCount=n;}catch(Exception e){streamError("평면",e);}}
    }
    void drawModel(float[] mvp,float size){drawBuffers(mvp,size,positions,colors,count,drawMode,neutralTint,false);}
    void drawBuffers(float[] mvp,float size,FloatBuffer pos,ByteBuffer col,int num,int mode,float[] tint,boolean useTint){if(num==0||pos==null||col==null)return;GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glDisable(GLES20.GL_CULL_FACE);GLES20.glUseProgram(program);GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"mvp"),1,false,mvp,0);GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"pt"),size);GLES20.glUniform4fv(GLES20.glGetUniformLocation(program,"tint"),1,tint,0);GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"useTint"),useTint?1:0);int a=GLES20.glGetAttribLocation(program,"aPos"),b=GLES20.glGetAttribLocation(program,"aColor");pos.position(0);col.position(0);GLES20.glEnableVertexAttribArray(a);GLES20.glEnableVertexAttribArray(b);GLES20.glVertexAttribPointer(a,3,GLES20.GL_FLOAT,false,0,pos);GLES20.glVertexAttribPointer(b,4,GLES20.GL_UNSIGNED_BYTE,true,0,col);GLES20.glDrawArrays(mode,0,num);GLES20.glDisableVertexAttribArray(a);GLES20.glDisableVertexAttribArray(b);}
    // Depth pixels are in native GPU texture orientation. Convert their UV to CPU image UV for colour.
    int capture(Frame frame,Image dep,Image conf,Image rgb,boolean surface,boolean addPoints){int w=dep.getWidth(),h=dep.getHeight();if(conf!=null&&(conf.getWidth()!=w||conf.getHeight()!=h))return 0;CameraIntrinsics intr=frame.getCamera().getTextureIntrinsics();float[] f=intr.getFocalLength(),p=intr.getPrincipalPoint();int[] dim=intr.getImageDimensions();float fx=f[0]*w/dim[0],fy=f[1]*h/dim[1],cx=p[0]*w/dim[0],cy=p[1]*h/dim[1];
        Image.Plane dp=dep.getPlanes()[0];ByteBuffer db=dp.getBuffer().order(ByteOrder.LITTLE_ENDIAN);Image.Plane cp=conf==null?null:conf.getPlanes()[0];ByteBuffer cb=cp==null?null:cp.getBuffer();Image.Plane[] rgbp=rgb==null?null:rgb.getPlanes();if(rgbp!=null&&rgbp.length<3)rgbp=null;
        String stats=Geometry.depthStats(db,w,h,dp.getRowStride(),dp.getPixelStride(),cb,cp==null?0:cp.getRowStride(),cp==null?0:cp.getPixelStride());if(surface)denseStats=stats;else rawStats=stats;
        int step=surface?Math.max(2,w/80):Math.max(1,w/150),gw=(w+step-1)/step,gh=(h+step-1)/step,n=gw*gh;float[] uv=new float[n*2],cpu=new float[n*2];for(int j=0;j<gh;j++)for(int i=0;i<gw;i++){int k=j*gw+i;uv[2*k]=(i*step+.5f)/w;uv[2*k+1]=(j*step+.5f)/h;}
        if(rgbp!=null){try{frame.transformCoordinates2d(Coordinates2d.TEXTURE_NORMALIZED,uv,Coordinates2d.IMAGE_PIXELS,cpu);}catch(Exception e){streamError("RGB 좌표 변환",e);rgbState="좌표 변환 오류 · 회색 깊이";rgbp=null;}}float[][] vertices=surface?new float[n][]:null;int[] cs=surface?new int[n]:null;Pose pose=frame.getCamera().getPose();int added=0;
        for(int j=0;j<gh;j++)for(int i=0;i<gw;i++){int x=i*step,y=j*step,k=j*gw+i,idx=db.position()+y*dp.getRowStride()+x*dp.getPixelStride();if(idx+1>=db.limit())continue;int mm=Geometry.readU16(db,idx);if(mm<Geometry.MIN_DEPTH_MM||mm>Geometry.MAX_DEPTH_MM)continue;if(cb!=null){int ci=cb.position()+y*cp.getRowStride()+x*cp.getPixelStride();if(ci>=cb.limit()||(cb.get(ci)&255)<Geometry.MIN_CONFIDENCE)continue;}float u=cpu[2*k],v=cpu[2*k+1];int color=0xa6a6a6;if(rgbp!=null&&Float.isFinite(u)&&Float.isFinite(v)&&u>=0&&u<rgb.getWidth()&&v>=0&&v<rgb.getHeight()){int px=(int)u,py=(int)v;color=Geometry.rgb(sample(rgbp[0],px,py),sample(rgbp[1],px/2,py/2),sample(rgbp[2],px/2,py/2));}float[] point=pose.transformPoint(Geometry.unproject(x+.5f,y+.5f,mm*.001f,fx,fy,cx,cy));if(!Geometry.valid(point))continue;if(surface){vertices[k]=point;cs[k]=color;}if(addPoints){store.point(point,color);if(!surface)added++;}}
        if(surface){int prev=store.triCount();for(int j=0;j<gh-1;j++)for(int i=0;i<gw-1;i++){int a=j*gw+i,b=a+1,c=a+gw,d=c+1;store.triangle(vertices[a],vertices[c],vertices[b],cs[a],cs[c],cs[b]);store.triangle(vertices[b],vertices[c],vertices[d],cs[b],cs[c],cs[d]);}added=store.triCount()-prev;}return added;
    }
    static int sample(Image.Plane p,int x,int y){ByteBuffer b=p.getBuffer();int k=b.position()+y*p.getRowStride()+x*p.getPixelStride();return k>=0&&k<b.limit()?b.get(k)&255:128;}
}
