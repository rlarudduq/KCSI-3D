package kr.kcsi.scenescan;

import android.media.Image;
import android.opengl.*;
import android.os.SystemClock;
import com.google.ar.core.*;
import com.google.ar.core.exceptions.NotYetAvailableException;
import java.nio.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

final class ScanRenderer implements GLSurfaceView.Renderer {
    final MainActivity activity; final Geometry.Store store=new Geometry.Store();
    volatile Session session; int width=1,height=1,texture,background,program;
    boolean recording=false,review=false,mesh=false,liveOverlay=true;
    int frames=0,meshFrames=0; long lastRaw=-1,lastCapture=0,lastMesh=0,lastUi=0,lastBuffer=0; Pose lastPose=null,lastSurfacePose=null;
    float yaw=.7f,pitch=.65f,zoom=1f; float[] center={0,0,0};float radius=2;
    FloatBuffer positions; ByteBuffer colors; int count=0,drawMode=GLES20.GL_POINTS; boolean dirty=true;
    final float[] quad={-1,-1,1,-1,-1,1,1,1}; final FloatBuffer quadBuf=fb(quad),uvBuf=fb(new float[8]);
    ScanRenderer(MainActivity a){activity=a;}
    static FloatBuffer fb(float[] f){FloatBuffer b=ByteBuffer.allocateDirect(f.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(f).position(0);return b;}
    static int shader(int type,String s){int id=GLES20.glCreateShader(type);GLES20.glShaderSource(id,s);GLES20.glCompileShader(id);int[] ok=new int[1];GLES20.glGetShaderiv(id,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)throw new IllegalStateException(GLES20.glGetShaderInfoLog(id));return id;}
    static int program(String v,String f){int a=shader(GLES20.GL_VERTEX_SHADER,v),b=shader(GLES20.GL_FRAGMENT_SHADER,f),p=GLES20.glCreateProgram();GLES20.glAttachShader(p,a);GLES20.glAttachShader(p,b);GLES20.glLinkProgram(p);int[] ok=new int[1];GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);GLES20.glDeleteShader(a);GLES20.glDeleteShader(b);if(ok[0]==0)throw new IllegalStateException(GLES20.glGetProgramInfoLog(p));return p;}
    public void onSurfaceCreated(GL10 gl,EGLConfig c){int[] t=new int[1];GLES20.glGenTextures(1,t,0);texture=t[0];GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
        background=program("attribute vec2 aPos;attribute vec2 aUV;varying vec2 vUV;void main(){gl_Position=vec4(aPos,0.,1.);vUV=aUV;}","#extension GL_OES_EGL_image_external : require\nprecision mediump float;varying vec2 vUV;uniform samplerExternalOES tex;void main(){gl_FragColor=texture2D(tex,vUV);}");
        program=program("attribute vec3 aPos;attribute vec4 aColor;uniform mat4 mvp;uniform float pt;varying vec4 vColor;void main(){gl_Position=mvp*vec4(aPos,1.);gl_PointSize=pt;vColor=aColor;}","precision mediump float;varying vec4 vColor;void main(){gl_FragColor=vColor;}");dirty=true;
    }
    public void onSurfaceChanged(GL10 gl,int w,int h){width=Math.max(1,w);height=Math.max(1,h);GLES20.glViewport(0,0,width,height);}
    void start(){recording=true;review=false;mesh=false;lastPose=null;lastSurfacePose=null;lastCapture=lastMesh=0;dirty=true;}
    void stop(){recording=false;review=true;mesh=false;fit();dirty=true;}
    void reset(){store.clear();frames=meshFrames=0;lastRaw=-1;lastPose=lastSurfacePose=null;lastCapture=lastMesh=0;recording=false;review=false;mesh=false;dirty=true;}
    void fit(){Geometry.Model m=store.snapshot(false);if(m.size()==0)m=store.snapshot(true);if(m.size()==0)return;float[] b=Geometry.bounds(m);for(int i=0;i<3;i++)center[i]=(b[i]+b[i+3])/2;radius=Math.max(.4f,(float)Math.sqrt(Math.pow(b[3]-b[0],2)+Math.pow(b[4]-b[1],2)+Math.pow(b[5]-b[2],2))/2);zoom=1;}
    void setMesh(boolean v){mesh=v;dirty=true;}
    void rotate(float dx,float dy){yaw+=dx*.008f;pitch=Math.max(-1.45f,Math.min(1.45f,pitch+dy*.008f));}
    void scale(float factor){zoom=Math.max(.25f,Math.min(5f,zoom/factor));}
    void refresh(boolean useMesh){Geometry.Model m=store.snapshot(useMesh);positions=fb(m.xyz);colors=ByteBuffer.allocateDirect(m.rgba.length);colors.put(m.rgba).position(0);count=m.size();drawMode=useMesh?GLES20.GL_TRIANGLES:GLES20.GL_POINTS;dirty=false;lastBuffer=SystemClock.elapsedRealtime();}
    public void onDrawFrame(GL10 gl){GLES20.glClearColor(.043f,.075f,.11f,1);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);long now=SystemClock.elapsedRealtime();
        if(review){if(dirty)refresh(mesh);float[] view=new float[16],proj=new float[16],mvp=new float[16];float r=radius*2.8f*zoom;Matrix.setLookAtM(view,0,center[0]+r*(float)(Math.cos(pitch)*Math.sin(yaw)),center[1]+r*(float)Math.sin(pitch),center[2]+r*(float)(Math.cos(pitch)*Math.cos(yaw)),center[0],center[1],center[2],0,1,0);Matrix.perspectiveM(proj,0,50,width/(float)height,.025f,Math.max(50,radius*20));Matrix.multiplyMM(mvp,0,proj,0,view,0);drawModel(mvp,3.5f);return;}
        Session s=session;if(s==null)return;
        try{s.setCameraTextureName(texture);s.setDisplayGeometry(activity.displayRotation(),width,height);Frame frame=s.update();Camera cam=frame.getCamera();if(frame.getTimestamp()!=0)drawBackground(frame);
            String state=cam.getTrackingState()==TrackingState.TRACKING?"추적 정상":"추적 대기 · 주변을 천천히 촬영";
            if(recording&&cam.getTrackingState()==TrackingState.TRACKING){Pose pose=cam.getPose();boolean rawDue=now-lastCapture>=350&&moved(lastPose,pose,.065f,7);boolean meshDue=now-lastMesh>=1100&&moved(lastSurfacePose,pose,.22f,16)&&store.triCount()<Geometry.TRI_LIMIT;
                if(rawDue||meshDue){try(Image rgb=frame.acquireCameraImage()){
                    if(rawDue){try(Image dep=frame.acquireRawDepthImage16Bits(); Image confidence=frame.acquireRawDepthConfidenceImage()){
                        if(dep.getTimestamp()!=lastRaw && dep.getTimestamp()==frame.getTimestamp()){int added=capture(frame,dep,confidence,rgb,false);lastRaw=dep.getTimestamp();if(added>0){frames++;lastPose=pose;lastCapture=now;dirty=true;}}
                    }catch(NotYetAvailableException ignored){}}
                    if(meshDue){try(Image dep=frame.acquireDepthImage16Bits()){int added=capture(frame,dep,null,rgb,true);if(added>0){meshFrames++;lastSurfacePose=pose;lastMesh=now;}}catch(NotYetAvailableException ignored){}}
                }catch(NotYetAvailableException ignored){}}
            }
            if(recording&&liveOverlay&&cam.getTrackingState()==TrackingState.TRACKING){if(dirty&&now-lastBuffer>=350)refresh(false);float[] view=new float[16],proj=new float[16],mvp=new float[16];cam.getViewMatrix(view,0);cam.getProjectionMatrix(proj,0,.05f,50f);Matrix.multiplyMM(mvp,0,proj,0,view,0);drawModel(mvp,2.5f);}
            if(now-lastUi>=400){lastUi=now;activity.status(state,frames,store.count(),store.triCount(),recording);}
        }catch(Exception e){recording=false;activity.renderError(e);}
    }
    static boolean moved(Pose old,Pose next,float metres,float degrees){if(old==null)return true;float[] a=old.getTranslation(),b=next.getTranslation();if(Geometry.dist2(a,b)>=metres*metres)return true;float[] q=old.getRotationQuaternion(),r=next.getRotationQuaternion();double dot=Math.abs(q[0]*r[0]+q[1]*r[1]+q[2]*r[2]+q[3]*r[3]);return 2*Math.acos(Math.min(1,dot))*180/Math.PI>=degrees;}
    void drawBackground(Frame frame){float[] uv=new float[8];frame.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,quad,Coordinates2d.TEXTURE_NORMALIZED,uv);uvBuf.position(0);uvBuf.put(uv).position(0);GLES20.glDisable(GLES20.GL_DEPTH_TEST);GLES20.glDepthMask(false);GLES20.glUseProgram(background);GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glUniform1i(GLES20.glGetUniformLocation(background,"tex"),0);int p=GLES20.glGetAttribLocation(background,"aPos"),u=GLES20.glGetAttribLocation(background,"aUV");quadBuf.position(0);GLES20.glEnableVertexAttribArray(p);GLES20.glEnableVertexAttribArray(u);GLES20.glVertexAttribPointer(p,2,GLES20.GL_FLOAT,false,0,quadBuf);GLES20.glVertexAttribPointer(u,2,GLES20.GL_FLOAT,false,0,uvBuf);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);GLES20.glDisableVertexAttribArray(p);GLES20.glDisableVertexAttribArray(u);GLES20.glDepthMask(true);}
    void drawModel(float[] mvp,float size){if(count==0||positions==null||colors==null)return;GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glDisable(GLES20.GL_CULL_FACE);GLES20.glUseProgram(program);GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"mvp"),1,false,mvp,0);GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"pt"),size);int a=GLES20.glGetAttribLocation(program,"aPos"),b=GLES20.glGetAttribLocation(program,"aColor");positions.position(0);colors.position(0);GLES20.glEnableVertexAttribArray(a);GLES20.glEnableVertexAttribArray(b);GLES20.glVertexAttribPointer(a,3,GLES20.GL_FLOAT,false,0,positions);GLES20.glVertexAttribPointer(b,4,GLES20.GL_UNSIGNED_BYTE,true,0,colors);GLES20.glDrawArrays(drawMode,0,count);GLES20.glDisableVertexAttribArray(a);GLES20.glDisableVertexAttribArray(b);}
    // Depth pixels are in native GPU texture orientation. Convert their UV to CPU image UV for colour.
    int capture(Frame frame,Image dep,Image conf,Image rgb,boolean surface){int w=dep.getWidth(),h=dep.getHeight();if(conf!=null&&(conf.getWidth()!=w||conf.getHeight()!=h))return 0;CameraIntrinsics intr=frame.getCamera().getTextureIntrinsics();float[] f=intr.getFocalLength(),p=intr.getPrincipalPoint();int[] dim=intr.getImageDimensions();float fx=f[0]*w/dim[0],fy=f[1]*h/dim[1],cx=p[0]*w/dim[0],cy=p[1]*h/dim[1];
        Image.Plane dp=dep.getPlanes()[0];ByteBuffer db=dp.getBuffer().order(ByteOrder.LITTLE_ENDIAN);Image.Plane cp=conf==null?null:conf.getPlanes()[0];ByteBuffer cb=cp==null?null:cp.getBuffer();Image.Plane[] rgbp=rgb.getPlanes();if(rgbp.length<3)return 0;
        int step=surface?Math.max(3,w/42):Math.max(1,w/150),gw=(w+step-1)/step,gh=(h+step-1)/step,n=gw*gh;float[] uv=new float[n*2],cpu=new float[n*2];for(int j=0;j<gh;j++)for(int i=0;i<gw;i++){int k=j*gw+i;uv[2*k]=(i*step+.5f)/w;uv[2*k+1]=(j*step+.5f)/h;}
        frame.transformCoordinates2d(Coordinates2d.TEXTURE_NORMALIZED,uv,Coordinates2d.IMAGE_NORMALIZED,cpu);float[][] vertices=surface?new float[n][]:null;int[] cs=surface?new int[n]:null;Pose pose=frame.getCamera().getPose();int added=0;
        for(int j=0;j<gh;j++)for(int i=0;i<gw;i++){int x=i*step,y=j*step,k=j*gw+i,idx=db.position()+y*dp.getRowStride()+x*dp.getPixelStride();if(idx+1>=db.limit())continue;int mm=db.getShort(idx)&65535;if(mm<350||mm>5000)continue;if(cb!=null){int ci=cb.position()+y*cp.getRowStride()+x*cp.getPixelStride();if(ci>=cb.limit()||(cb.get(ci)&255)<110)continue;}float u=cpu[2*k],v=cpu[2*k+1];if(!Float.isFinite(u)||!Float.isFinite(v)||u<0||u>=1||v<0||v>=1)continue;int px=Math.min(rgb.getWidth()-1,(int)(u*rgb.getWidth())),py=Math.min(rgb.getHeight()-1,(int)(v*rgb.getHeight()));int color=Geometry.rgb(sample(rgbp[0],px,py),sample(rgbp[1],px/2,py/2),sample(rgbp[2],px/2,py/2));float[] point=pose.transformPoint(Geometry.unproject(x+.5f,y+.5f,mm*.001f,fx,fy,cx,cy));if(!Geometry.valid(point))continue;if(surface){vertices[k]=point;cs[k]=color;}else{store.point(point,color);added++;}}
        if(surface){int prev=store.triCount();for(int j=0;j<gh-1;j++)for(int i=0;i<gw-1;i++){int a=j*gw+i,b=a+1,c=a+gw,d=c+1;store.triangle(vertices[a],vertices[c],vertices[b],cs[a],cs[c],cs[b]);store.triangle(vertices[b],vertices[c],vertices[d],cs[b],cs[c],cs[d]);}added=store.triCount()-prev;}return added;
    }
    static int sample(Image.Plane p,int x,int y){ByteBuffer b=p.getBuffer();int k=b.position()+y*p.getRowStride()+x*p.getPixelStride();return k>=0&&k<b.limit()?b.get(k)&255:128;}
}
